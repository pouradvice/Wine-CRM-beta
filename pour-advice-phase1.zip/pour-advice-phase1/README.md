# Pour Advice CRM — Phase 1

> Internal broker CRM for tasting recap capture and product performance analytics.

---

## Project Structure

```
pour-advice/
├── src/
│   ├── app/
│   │   ├── (auth)/
│   │   │   └── login/
│   │   │       └── page.tsx          # Supabase Auth login page
│   │   ├── app/
│   │   │   └── crm/
│   │   │       ├── clients/
│   │   │       │   └── page.tsx      # Client list + slideover
│   │   │       ├── buyers/
│   │   │       │   └── page.tsx      # Buyer list
│   │   │       ├── products/
│   │   │       │   └── page.tsx      # Product catalog
│   │   │       ├── new-recap/
│   │   │       │   └── page.tsx      # ← Recap entry (primary workflow)
│   │   │       ├── history/
│   │   │       │   └── page.tsx      # Recap history
│   │   │       ├── follow-ups/
│   │   │       │   └── page.tsx      # Open follow-up queue
│   │   │       └── reports/
│   │   │           └── page.tsx      # Phase 1 reports (4 views)
│   │   ├── api/
│   │   │   ├── products/
│   │   │   │   ├── route.ts          # GET /api/products, POST
│   │   │   │   └── [id]/route.ts     # GET/PATCH/DELETE by id
│   │   │   ├── clients/
│   │   │   │   ├── route.ts
│   │   │   │   └── [id]/route.ts
│   │   │   ├── buyers/
│   │   │   │   ├── route.ts
│   │   │   │   └── [id]/route.ts
│   │   │   ├── recaps/
│   │   │   │   ├── route.ts          # POST saves recap + products + follow-ups
│   │   │   │   └── [id]/route.ts
│   │   │   └── follow-ups/
│   │   │       └── [id]/route.ts     # PATCH to complete/snooze
│   │   ├── layout.tsx                # Root layout with fonts
│   │   └── globals.css               # Design tokens + reset
│   ├── components/
│   │   ├── RecapForm/
│   │   │   ├── RecapForm.tsx         # ← Primary form (delivered)
│   │   │   └── RecapForm.module.css
│   │   ├── ui/
│   │   │   ├── Button.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── FormControl.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── Slideover.tsx
│   │   │   └── LoadingSpinner.tsx
│   │   └── layout/
│   │       ├── Nav.tsx               # Tab navigation
│   │       └── WideLayout.tsx
│   ├── lib/
│   │   ├── supabase/
│   │   │   ├── client.ts             # Browser client
│   │   │   └── server.ts             # Server client + service role
│   │   ├── data.ts                   # All DB access functions
│   │   └── analytics-queries.sql    # Raw SQL for Supabase SQL editor
│   ├── types/
│   │   └── index.ts                  # All TypeScript types
│   └── middleware.ts                 # Auth guard + session refresh
├── 01_schema.sql                     # Run once in Supabase SQL editor
├── .env.local.example
└── package.json
```

---

## Setup

### 1. Create Next.js project

```bash
npx create-next-app@latest pour-advice \
  --typescript \
  --app \
  --src-dir \
  --no-tailwind

cd pour-advice
npm install @supabase/ssr @supabase/supabase-js
```

### 2. Configure environment variables

Copy `.env.local.example` to `.env.local`:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key   # server only, never expose
```

### 3. Run the schema

Open the Supabase SQL editor for your project and run `01_schema.sql` in full.
This creates all tables, views, indexes, triggers, and RLS policies.

### 4. Connect to Vercel

```bash
npx vercel link
npx vercel env pull .env.local   # pulls env vars from Vercel
```

### 5. Start dev server

```bash
npm run dev
```

---

## Key Design Decisions

**Single data access layer (`src/lib/data.ts`)**
All Supabase queries live in one file. Server components and API routes both import from here. No query duplication.

**Server components by default**
Pages fetch data on the server and pass it as props to client components. The `RecapForm` is the only Client Component needed for Phase 1 because it manages local form state.

**Recap save is atomic from the user's perspective**
`saveRecap()` in `data.ts` inserts the recap, then recap_products, then auto-generates follow-up records in sequence. A Supabase RPC function can wrap this in a real transaction for Phase 2 if needed.

**Follow-ups auto-generated**
Any `recap_product` with outcome `Yes Later` or `Maybe Later` automatically creates a `follow_up` record. No manual step required from the specialist.

**is_active soft-deletes everywhere**
No hard deletes. Products and clients are archived, never removed. This preserves historical recap data integrity.

**CSS Modules + design tokens**
Token vocabulary (`--ink`, `--wine`, `--gold`, `--sage`, `--parchment`, `--cream`, `--mist`) matches the beta. No Tailwind. Brand consistency is non-negotiable.

---

## Phase 2 Additions (not in scope now)

- KPI dashboard tiles
- Salesperson / manager dashboards  
- Expense reports by supplier
- Multi-user role scoping (RLS team_id policies)
- Weekly auto-generated summaries
- Supplier + distributor portals
